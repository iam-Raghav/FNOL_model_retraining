# ADR — FNOL Triage Fine-Tuning

## Base model: Llama-3.1-8B-Instruct

Bake-off against Mistral-7B-v0.2, Qwen2.5-7B, Phi-3.5-mini, Nemo-12B on 50 hand-curated FNOLs. Llama tokenized insurance jargon (`CG 00 01`, policy numbers, `UIM`) ~14% denser than Mistral, hit 94% parseable JSON zero-shot (Mistral 71%), and led routing F1 0.62 vs 0.48. Qwen was close and has the cleanest license — worth re-running next cycle. Nemo-12B doesn't fit T4 at 4-bit with batch=4. Numbers come from a small set, so treat the ranking as directional.

## QLoRA over LoRA / full FT

Full FT needs ~64GB, bf16 LoRA ~32GB, QLoRA lands at ~12.5GB on T4 with room for batch=4. 2–5% F1 gap vs full FT on classification is acceptable here. Separate adapter is also a hard requirement for the split-view demo and rollback. Rank=16, alpha=32 — r=8 felt thin given 5 domain signals × 4 output dimensions; ~50MB extra is free.

## Single-shot JSON output

The four labels co-determine each other (a slip-and-fall fixes coverage, severity, and routing in one move). Four separate calls quadruple latency and lose that joint reasoning. JSON parses cleanly; malformed output is scored wrong in `evaluate.py`.

## Confidence threshold = 0.65 (low confidence here)

Mean token probability < 0.65 → flag for review. The threshold is gut feel, not calibrated, and mean token prob is a proxy — models can be confidently wrong. Next step: Platt scaling on 200–300 labeled FNOLs, then anchor the cutoff to a real accuracy drop-off.
